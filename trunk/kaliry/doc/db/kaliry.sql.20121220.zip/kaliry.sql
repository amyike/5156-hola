-- phpMyAdmin SQL Dump
-- version 3.4.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 12 月 20 日 06:04
-- 服务器版本: 5.1.46
-- PHP 版本: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `kaliry`
--

-- --------------------------------------------------------

--
-- 表的结构 `tb_master`
--

CREATE TABLE IF NOT EXISTS `tb_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL COMMENT '地区',
  `city` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `authority` smallint(1) NOT NULL DEFAULT '3' COMMENT '权限：1超级管理员；2高级管理员；3普通管理员；',
  `time` datetime NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=25 ;

--
-- 转存表中的数据 `tb_master`
--

INSERT INTO `tb_master` (`id`, `account`, `password`, `province`, `city`, `company`, `authority`, `time`) VALUES
(1, 'admin', '4297F44B13955235245B2497399D7A93', '浙江', '杭州', '总部', 1, '2012-12-03 14:14:18'),
(2, 'hzwanglp', '4297f44b13955235245b2497399d7a93', '浙江', '杭州', '总部', 1, '2012-12-04 10:24:53'),
(5, 'hywuy', '4297f44b13955235245b2497399d7a93', '浙江', '海盐', '海盐', 3, '2012-12-07 11:22:14'),
(8, 'wzzhoupw', '4297f44b13955235245b2497399d7a93', '浙江', '温州', '温州', 3, '2012-12-10 10:36:30'),
(9, 'zjzhaob', '4297f44b13955235245b2497399d7a93', '浙江', '绍兴', '诸暨', 3, '2012-12-10 10:38:09'),
(10, 'sychenmh', '4297f44b13955235245b2497399d7a93', '浙江', '绍兴', '上虞', 3, '2012-12-10 10:39:04'),
(11, 'kqzhujq', '5a772f10df01b46887eac53cc2b8f635', '浙江', '绍兴', '柯桥', 3, '2012-12-10 10:41:12'),
(12, 'sxhesh', '4297f44b13955235245b2497399d7a93', '浙江', '绍兴', '绍兴', 3, '2012-12-10 10:41:52'),
(13, 'ttzhumn', '4297f44b13955235245b2497399d7a93', '浙江', '台州', '天台', 3, '2012-12-10 10:43:06'),
(14, 'lhguow', '3b42e84085a9c32b46556735275ca3ac', '浙江', '台州', '临海', 3, '2012-12-10 10:43:37'),
(15, 'hzshall', '4297f44b13955235245b2497399d7a93', '浙江', '湖州', '湖州', 3, '2012-12-10 10:44:09'),
(16, 'nbshenpy', 'b0f06045099e2f1412942f69dfd3009f', '浙江', '宁波', '宁波', 3, '2012-12-10 10:44:59'),
(17, 'jhsily', '4297f44b13955235245b2497399d7a93', '金华', '金华', '金华', 3, '2012-12-10 10:45:36'),
(18, 'ykyinghy', 'acd9856da113b5e8373e9e385dc14ab8', '浙江', '金华', '永康', 3, '2012-12-10 10:46:22'),
(19, 'xhsunt', '13da68a69acf99a6ce6f5c4066fb8d3f', '浙江', '杭州', '西湖', 3, '2012-12-10 10:47:03'),
(20, 'wlxiangpc', '4297f44b13955235245b2497399d7a93', '浙江', '杭州', '武林', 3, '2012-12-10 10:47:35'),
(21, 'fyliy', '4297f44b13955235245b2497399d7a93', '浙江', '杭州', '富阳', 3, '2012-12-10 10:48:02'),
(22, 'test', 'e10adc3949ba59abbe56e057f20f883e', '浙江', '绍兴', '绍兴', 3, '2012-12-11 15:43:08'),
(23, 'wangjm', 'e10adc3949ba59abbe56e057f20f883e', '浙江', '杭州', 'IT', 3, '2012-12-12 13:50:34'),
(24, 'hzdengyy', '4297f44b13955235245b2497399d7a93', '浙江', '杭州', '总部', 1, '2012-12-20 09:18:08');

-- --------------------------------------------------------

--
-- 表的结构 `tb_member`
--

CREATE TABLE IF NOT EXISTS `tb_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` bigint(14) NOT NULL COMMENT '编号',
  `name` varchar(255) NOT NULL COMMENT '姓名',
  `idcard` varchar(18) NOT NULL COMMENT '身份证号码',
  `province` varchar(64) NOT NULL COMMENT '身份',
  `city` varchar(64) NOT NULL COMMENT '市',
  `company` varchar(255) NOT NULL,
  `open_way` smallint(1) NOT NULL COMMENT '会员卡开通方式',
  `tel` varchar(64) NOT NULL COMMENT '联系电话',
  `pickup_way` smallint(1) NOT NULL COMMENT '取货方式',
  `send_addr` varchar(255) NOT NULL COMMENT '送货地址',
  `purchase_intention` varchar(32) NOT NULL COMMENT '意向认购',
  `customer_signature` varchar(255) NOT NULL COMMENT '客户签名',
  `apply_time` datetime DEFAULT NULL COMMENT '申请日期',
  `servicer_id` bigint(14) NOT NULL COMMENT '服务专员编号',
  `servicer_name` varchar(255) NOT NULL COMMENT '服务专员名字',
  `is_accept` smallint(1) DEFAULT NULL COMMENT '是否受理',
  `entry_time` datetime DEFAULT NULL COMMENT '录入日期',
  `activate_time` datetime DEFAULT NULL COMMENT '激活生效时间',
  `assignees` varchar(255) DEFAULT NULL COMMENT '受理人',
  `cardno` decimal(14,0) DEFAULT NULL COMMENT '会员卡号',
  `signer` varchar(255) DEFAULT NULL COMMENT '签收人',
  `sign_time` datetime DEFAULT NULL COMMENT '签收日期',
  `credits` int(9) NOT NULL DEFAULT '0' COMMENT '积分',
  `state` smallint(1) NOT NULL COMMENT '状态:1激活;2弃用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idcard` (`idcard`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tb_redeem_record`
--

CREATE TABLE IF NOT EXISTS `tb_redeem_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '物品名',
  `number` int(9) NOT NULL COMMENT '兑换数量',
  `time` datetime NOT NULL COMMENT '兑换时间',
  `member_id` int(11) NOT NULL COMMENT '会员ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `tb_trade_record`
--

CREATE TABLE IF NOT EXISTS `tb_trade_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_no` varchar(64) NOT NULL COMMENT '物品编号',
  `name` varchar(255) NOT NULL COMMENT '物品名',
  `price` decimal(9,2) NOT NULL,
  `number` int(9) NOT NULL,
  `money` decimal(9,2) NOT NULL,
  `type` smallint(1) NOT NULL COMMENT '1购买记录;2退货记录',
  `time` datetime NOT NULL,
  `member_id` int(11) NOT NULL COMMENT '会员ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
